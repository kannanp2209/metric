const express = require('express');
var jwt = require('jsonwebtoken');
const config = require('../config.js');
var Common = require('../models/Common.js');
var EmployeeModel = require('../models/EmployeeModel.js');
var tables = require("../models/TablesModel.js");
const router = express.Router();
var EmployeeModel = new EmployeeModel();
var dbTable = tables.table;

router.get("/test", (req, res, next) => {
    res.json(Common.jsonCovert("success", "This is Employee Test Api.", 1));
});



module.exports = router;
