'use strict';

var express = require('express');
var Common = require('../models/Common.js');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.json(Common.jsonCovert("success", "This is Home Page", 11));
});

router.get('/test', function(req, res, next) {
  res.json(Common.jsonCovert("success", "This is Test Home Page", 11));
});


module.exports = router;
