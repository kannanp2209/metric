module.exports = {
  secret: 'worldisfullofdevelopers'
};