'use strict';
var nodemailer = require('nodemailer');
var moment = require('moment-timezone');
var request = require('request');

	function jsonCovert(status, content, value) 
	{
		return {"status": status, "content": content, "value": value};
	}
	
	function jsonCovertToken(status, content, value, token) 
	{
		return {"status": status, "content": content, "value": value, "token": token};
	}
	
	function ConvertTime(LocationId, DateTime)
	{
		var TimeZone = '';
		if(LocationId == 1) {
			/* ----------- India Location ----------- */
			TimeZone = 'Asia/Kolkata';
		} else if(LocationId == 2) {
			/* ----------- Poland Location ----------- */
			TimeZone = 'Europe/Warsaw';
		} else if(LocationId == 3) {
			/* ----------- German Location ----------- */
			TimeZone = 'Europe/Berlin';
		} else if(LocationId == 4) {
			/* ----------- Brazil Location ----------- */
			TimeZone = 'America/Sao_Paulo';
		}
		else if(LocationId == 5) {
			/* ----------- Brazil Location ----------- */
			TimeZone = 'Asia/Shanghai';
		} else {
			TimeZone = 'Asia/Kolkata';
		}
		
		if(DateTime == '') { DateTime = new Date(); }
			
		const ConvertedTime = moment.tz(DateTime, TimeZone).format("yyyy-MM-DD hh:MM:ss");
		return ConvertedTime;
	}
	function SendEmail(fromMail, toMail, ccMail, subject, body, Attachments)
	{
		fromMail = 'noreply-gembawalker@zf.com';
		var transporter = nodemailer.createTransport({
			host: 'Frd-mail.emea.zf-world.com',
			port: 25,
			secure: false,
			requireTLS: false
		});
		
		if(Attachments != '' && Attachments != null) {
			var mailOptions = {
				from: fromMail,
				to: toMail,
				cc: ccMail,
				subject: subject,
				html: body,
				attachments: [{ filename: Attachments, path: 'https://mobility-services.wabco-auto.com/randomaudit/GetImage?image='+Attachments }]
			};
		} else {
			var mailOptions = {
				from: fromMail,
				to: toMail,
				cc: ccMail,
				subject: subject,
				html: body
			};
		}
		transporter.sendMail(mailOptions, function(error, info){
			if (error) {
				console.log(error);
			} else {
				console.lo("Success");
			}
		});
	}

	function SendMailtriger(toMail, ccMail, subject, body, attachments) 
	{
		var fromMail = 'noreply-gembawalker@zf.com';
		let params = {
			"fromMail": fromMail,
			"toMail": toMail,
			"ccMail": ccMail,
			"subject": subject,
			"body": body,
			"attachments": attachments
		}
		const requestOptions = {
			url: 'https://mobility-services.wabco-auto.com/mailtriger/sendmail',
			method: 'post',
			json: true,
			headers: {
			'Content-Type': 'application/json'
			},
			body: params	
		};
		request.post(requestOptions, function(error, response, body) {
			return true;
		});
	}


	module.exports.jsonCovert = jsonCovert;
	module.exports.jsonCovertToken = jsonCovertToken;
	module.exports.ConvertTime = ConvertTime;
	module.exports.SendEmail = SendEmail;
	module.exports.SendMailtriger = SendMailtriger;
	