 
module.exports.databaseOptions = {
	server:'cvcs-mobility.database.windows.net',
  port: 1433,
  database:'GembawalkerDev',
  user:'gembawalker-dev',
  password:'p$jiD5B3b3tBz%s3'
}; 

/*
module.exports.databaseOptions = {
	server:'wdegssqlt5',
    database:'MEProcess',
    user:'MEProcess',
    password:'eLX6HOpYQUAAGkeq0iye'					
}; */