'use strict';
const sql = require('mssql');
var dbConnection = require("./ConnectionModel.js");
var tables = require("./TablesModel.js");
var jwt = require('jsonwebtoken');
var dbConfig = dbConnection.databaseOptions;
var dbTable = tables.table;

	
module.exports = class LoginModel {
	constructor() {
		//dbConnection.connect();
		
	}
  	
	async JWTTokenUpdate(tableName, DomainName, JWTToken, AdminUserOTP) {
		return new Promise((resolve, reject) => {
		   new sql.ConnectionPool(dbConfig).connect().then(pool => {
			   let Query = "update " + tableName + " set AdminToken=@JWTToken, AdminUserOTP=@AdminUserOTP where DomainName=@DomainName";
			   console.log(Query);
			   return pool.request()
				   .input('JWTToken',JWTToken)
				   .input('AdminUserOTP',AdminUserOTP)
				   .input('DomainName',DomainName)
				   .query(Query);
		   }).then(result => {
			   resolve(1);
			   sql.close();
		   }).catch(err => {
			   reject(err)
			   sql.close();
		   });
	   });
   }
   
   async OTPValidate(tableName, UserId, UserOTP, LocationId) {
	   
	   let pool = await sql.connect(dbConfig);
	   let Query = "select UserId,EmpId,FirstName,LastName,Email,DomainName,SuperAdmin,LocationId,Status  from " + tableName + " where UserId=@UserId and AdminUserOTP=@UserOTP and LocationId=@LocationId";
	   console.log(Query);
	   let data = await pool.request()
		   .input('UserId',UserId)
		   .input('UserOTP',UserOTP)
		   .input('LocationId',LocationId)
		   .query(Query);
	   pool.close;
	   sql.close;
	   return data.recordset;
   }
   
   async OTPUpdate(tableName, UserId, UserOTP) {
	   
	   return new Promise((resolve, reject) => {
		   new sql.ConnectionPool(dbConfig).connect().then(pool => { 
			   var Query = "UPDATE " + tableName + " set AdminUserOTP=@UserOTP where UserId=@UserId select UserId from " + tableName + " where UserId=@UserId";
			   console.log(Query);
			   return pool.request()
				   .input('UserOTP',UserOTP)
				   .input('UserId',UserId)
				   .query(Query)
		   }).then(result => {
			   resolve(result['recordset']);
			   sql.close();
		   }).catch(err => {
			   reject(err)
			   sql.close();
		   });
	   });
   } 

   async CheckUserTokenDetails(token) 
   {
		if(token == '') {
			return 0;
		}
		var TokenDecode = jwt.decode(token, { complete: true });
		console.log(TokenDecode);
		const currentTime = new Date().getTime();
		const currentTimeInSeconds = Math.floor(currentTime / 1000);
		const expiryTime = TokenDecode.payload.exp;
		var isExpired = expiryTime - currentTimeInSeconds; //it will be in minus value if expired	
		console.log("isexpiry=>", isExpired);


		if (isExpired > 0) {
			let pool = await sql.connect(dbConfig);
			var Query = "select * from " + dbTable.Users + " where EmpId=@UsersEmpId";
			console.log(Query);
			let data = await pool.request()
				.input('UsersEmpId',TokenDecode.payload.UsersEmpId)
				.query(Query);
			console.log("#########" + data.recordset.length);
			if (data.recordset.length > 0) {
				console.log(data['recordset'][0]);
				console.log(data['recordset'][0]['AdminToken']);
				console.log("-----------------------");
				console.log(token);
				if ((data['recordset'][0]['AdminToken']) == token) {
					console.log("true");
					return 1;
				} else {
					return 0;
				}
			} else {
				return 0;
			}
			pool.close;
			sql.close;
		} else {
			return 0;
		}
	}

	async LoginUserDetails(tableName, DomainName) {
        // var WhereCond = '';
        var subQuery = '';
        var subFeild = '';

        let pool = await sql.connect(dbConfig);
        let Query = "select a.UserId,a.EmpId,a.FirstName,a.LastName,a.Email,a.DomainName,a.LastLogin,a.SuperAdmin,a.LocationId,a.Status,b.LocationCode,b.LocationDateformat from " + tableName + " as a , " + dbTable.Locations + " as b where LOWER(a.DomainName)=LOWER(@DomainName) and a.LocationId=b.LocationId";
        console.log("Join", Query);
        let data = await pool.request()
            .input('DomainName',DomainName)
            .query(Query);
        pool.close;
        sql.close;
        return data.recordset;
    }

	async GetMiniAdminChecklist(tableName, UserId) {
        let pool = await sql.connect(dbConfig);
        let Query = "select * from " + tableName + " where ChecklistOwner=@UserId";
        let data = await pool.request()
            .input('UserId',UserId)
            .query(Query);
        pool.close;
        sql.close;
        return data.recordset;
    }
	
};

//export default Person;