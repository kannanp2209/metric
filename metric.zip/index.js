const express = require('express');
const path = require('path');

const fs = require('fs');

var jwt = require('jsonwebtoken');
const config = require('./config.js');
//var async = require("async");

const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');

var Common = require('./models/Common.js');
var LoginModel = require('./models/LoginModel.js');
var LoginModel = new LoginModel();

/* --------- JWT Token Validation -------------------- */
/*
var myLogger = function(req, res, next) {
    console.log("############################"+req.originalUrl);
    
    if (req.originalUrl == '/api/Login/LoginUserDetails') {
        next();
    } else {
        if (req.method == 'OPTIONS' || req.method == 'GET') {
            console.log(req.originalUrl + ' LOGGED ' + req.method);
            next();
        } else {
            console.log(req.originalUrl + ' LOGGED ' + req.method);
            var token = req.headers.authorization;
            if (typeof token === 'undefined' || token == '') {
                res.json(Common.jsonCovert("e_token", "Invalid token", 0));
            } else {
                console.log(token);
                LoginModel.CheckUserTokenDetails(token).then(checktoken => {
                    if (checktoken == 1) {
                        console.log("########" + token);
                        next()
                    } else {
                        res.json(Common.jsonCovert("e_token", "Invalid token", 0));
                    }
                });
            }
        }
    }
} */

/* --------- JWT Token Validation -------------------- */

const loginController = require('./controllers/login');
const employeeController = require('./controllers/employee');


const app = express();

//app.use(myLogger)

app.all("*", (req, res, next) => {
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","content-type");
    res.header("Access-Control-Allow-Methods","DELETE,PUT,POST,GET,OPTIONS");
    next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/login', loginController);
app.use('/api/employee', employeeController);


const port = process.env.PORT || 11566;
app.listen(port, () => {
    console.log("Server running on port 11566	");
});

app.all("/*", function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    next();
});

app.use((req, res, next) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private')
    next()
})

app.use('/api/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(express.static('data/img'));

module.exports = app;
